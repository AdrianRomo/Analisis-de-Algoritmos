Fourier.py

Welcome to the mysterious world of Fast Fourier Transformation, to begin, you have to execute the fourier.py program to see the third point in action, to do this you have to run in shell:

			$ python3 fourier.py

The only thing you have to check before running it, is the A.txt document, in this document you can modify the polynomial coefficients line by line.

You will see first the coefficients that were taken in A.txt and in second line the answer(s) you want to know :)

Complexity O(n log n)
