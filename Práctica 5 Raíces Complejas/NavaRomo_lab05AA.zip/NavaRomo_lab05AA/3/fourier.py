from cmath import exp
from math import pi

class NthRoot:
    def __init__(self, n, k = 1):
        self.k = k
        self.n = n
    def __eq__(self, other):
        if other == 1:
            return abs(self.n) == abs(self.k)

    def __mul__(self, other):
        return exp(2 * 1j * pi * self.k / self.n) * other

    def __pow__(self, other):
        if type(other) is int:
            n = NthRoot(self.n, self.k * other)
            return n
#    def __flag__(self):
#        return str(self.n) + "-th root of unity to the " + str(self.k)

    @property
    def th(self):
        return abs(self.n // self.k)

#Principal Function, FFT of Polynomials
def Poly(A, omega):
    if omega == 1:
        return [sum(A)]
    o2 = omega ** 2
    A1 = Poly(A[0::2], o2)
    A2 = Poly(A[1::2], o2)
    A3 = [None] * omega.th
    for i in range(omega.th // 2):
        #Even Half
        A3[i] = A1[i] + omega ** i * A2[i]
        #Odd Half
        A3[i + omega.th // 2] = A1[i] - omega ** i * A2[i]
    return A3

with open('A.txt', 'r') as f:
    A = f.read().splitlines()
A = [int(i) for i in A]
print(A)
n = 1 << (len(A) - 2).bit_length()
o = NthRoot(n)
print(Poly(A,o))
