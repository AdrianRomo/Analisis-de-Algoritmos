Root.py

Welcome to the mysterious world of Fast Fourier Transformation, to begin, you have to execute the root.py program to see the first and second points in action, to do this you have to run in shell:

			$ python3 root.py

Then you have to enter a number you want to evaluate and another number that will represent the Root.

After you see the result in the Shell, you will be asked for another number, this is to raise the principal root those number of times.