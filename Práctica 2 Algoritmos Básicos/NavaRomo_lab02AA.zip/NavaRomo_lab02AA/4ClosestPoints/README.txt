Given an array of coordinates of X,Y the program will calculate the shortest distance between two points.

The complexity of the algorithm used is O(n^2), cause the program will pass by all the points and comparing the slope with each other slopes.

Inputs: in Coordinates.txt are the coordinates and format to run the code

Outputs: In shell, the closest pair of points.


Compile & Run:

$ make