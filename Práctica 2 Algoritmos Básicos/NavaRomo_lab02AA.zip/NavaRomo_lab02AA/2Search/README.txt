Search

Entries: modify Search.txt

Output: Max number given in Linear and in Binary search

Eg: [1 2 3 4 5 4 3 2 1]

Linear Search : 5
Binary Search: 5

To Compile and run:

$ make

