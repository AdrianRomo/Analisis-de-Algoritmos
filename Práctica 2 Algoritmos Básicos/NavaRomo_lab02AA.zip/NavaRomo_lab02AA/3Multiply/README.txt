Input: 2 numbers A & B

Output: the result of A * B

Compile & Run:

$ make
