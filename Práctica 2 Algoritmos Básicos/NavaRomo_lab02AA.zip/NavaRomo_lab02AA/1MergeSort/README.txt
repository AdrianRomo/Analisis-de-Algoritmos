MergeSort

Entries: modify A.txt or B.txt

*Each file must have an ascending array.

Output: C.txt

This file contains A & B sorted in an ascending array.

To Compile and run:

$ make

