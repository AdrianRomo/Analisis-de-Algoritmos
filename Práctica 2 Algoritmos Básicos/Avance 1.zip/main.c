// main.c
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "bucketsort.h"

#define RANDOM_MAX 1001


/*
### Implementar Algoritmo de Ordenación por Bucket Sort
  - Vectores do Tipo Int, Positivo y generados de forma random con la función _rand()_.
  - Mayor valor de vector es definido por __RAND_MAX__ en este caso es 999
  - Se utilizan hilos con _Pthreads_
*/


int *random_array(size_t size);
void test_openmp(int *array, size_t size);
void test_pthreads(int *array, size_t size, int threads/*, time_t start*/);
int is_sort(int *sort, size_t size);
void print_array(int *array, size_t size);


int main(void){
  int *arrayn = NULL;
  int numrand = 0;
  int threads = 0;
  printf("Inserte número de cubetas a utilizar\n");
  scanf("%d",&numrand);
  printf("Inserte número de hilos\n");
  scanf("%d",&threads);
  // inicializamos el tiempo
  srand( (unsigned) time(NULL) );
//  time_t start = time(NULL);

  // Crea los vectores
  printf("Vector sin Ordenar: \n");
  arrayn = random_array(numrand);
  printf("Fin Vector sin Ordenar \n");

  test_pthreads(arrayn, numrand, threads/*, start*/);

  // Libera a memoria
  free(arrayn);

  return 0;
}

/** Función que posiciona un vector de números aleatorios de tamaño "size"
  * @param size - tamaño del vector
  */
int *random_array(size_t size){
  int *array = malloc(size * sizeof(int));
  for(size_t i = 0; i < size; i++){
    array[i] = (rand() % RANDOM_MAX);
    printf("A[%zu]: %d\n",i, array[i]);
  }
  return array;
}

/** Prueba ordenamiento utilizando pthreads con valor elegido
  * @param array - vector a ser ordenado
  * @param size - tamaño de vector
  */
void test_pthreads(int *array, size_t size, int threads/*, time_t start*/){
  int *sort = NULL;

  // Mensaje inicial
  printf("| Vector de tamaño %d:\n", (int) size);
  /*printf("| | Tiempo para ordenar: %.4f\n", (double)(time(NULL) - start));*/
  sort = bucket_sort_pthreads(array, size, RANDOM_MAX, threads);
  if(!is_sort(sort,size)){
    //printf("Arreglo no ordenado! :(\n");
    exit(0);
  } else{printf("Arreglo Ordenado Correctamente! :D\n");}
  free(sort);
  printf("| \n");
}

/** Función que pruebe si el vector esta ordenado
  * @param sort - vector
  * @param size - tamaño de vector
  */
int is_sort(int *sort, size_t size){
  for(size_t i = 1; i < size; i++){
    if (sort[i] < sort[i - 1])
      return 0;
  }
  return 1;
}
