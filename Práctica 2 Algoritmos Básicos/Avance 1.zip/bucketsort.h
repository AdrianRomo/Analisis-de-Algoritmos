// bucketsort.h
#ifndef _BUCKETSORT_H_
#define _BUCKETSORT_H_

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
/** Struct para representar un bucket
  * array - vector
  * size - tamaño de bucket
  */
typedef struct {
  int *array;
  size_t size;
}Bucket;

/** Funcion que hace bucket sort utilizando pthreads
	* @param array - vector a ser ordenado
	* @param size - tamaño de vector
	* @param max_value - mayor valor del vector
	* @param n_threads - cantidad de threads
	* @return vector ordenado
	*/
int *bucket_sort_pthreads(int *array, size_t size, int max_value, int n_threads);

/** Asigna buckets en la memoria
	*	@param n_arrays - cantidad de arrays que serán devueltos
	* @return n vectores
	*/
Bucket *allocate_buckets(int n_arrays);

/** Función que asigna valores a buckets
	* @param value - valor a indexar
	* @param max - valor maximo
	* @param n_buckets - cantidad de buckets
	* @return indice del vector
	*/
int get_bucket_index(int value, int max, int n_buckets);

/** Función que adiciona un valor al bucket
	* @param array - bucket
	* @param value - valor adicionado al bucket
	* @return bucket con un valor indexado
	*/
Bucket add_bucket_value(Bucket array, int value);

/** Algoritmo de ordenación Bubble Sort
	* @param array - Struct con un vector de su tamaño
	*/
void bubble_sort(void *array);

/** Función que combina los buckets con el vector resultado
	* @param sort_array - vector que inicia ordenamiento
	* @param buckets - vector de buckets
	* @param n_buckets - cantidad de buckets
	*/
void combine_buckets(int *sort_array, Bucket *buckets, int n_buckets);

/** Libera los buckets de la memoria
	* @param buckets - buckets
	* @param n_buckets - cantidad de buckets
	*/
void free_buckets(Bucket *buckets, int n_buckets);

#endif
