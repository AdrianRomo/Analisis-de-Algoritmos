// bucket.c
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <pthread.h>
#include "bucketsort.h"

/** Función que hace bucket sort utilizando pthreads
	* @param array - vector a ser ordenado
	* @param size - tamaño del vector
	* @param max_value - mayor valor del vector
	* @param n_threads - cantidad de threads
	* @return vector ordenado
	*/
int *bucket_sort_pthreads(int *array, size_t size, int max_value, int n_threads){
  pthread_t threads[n_threads];
	Bucket *buckets = NULL;
	int *sort_array = NULL;
	// Crea buckets
	buckets = allocate_buckets(n_threads);
	// Crea vector a ordenar
	sort_array = malloc(size * sizeof(int));

	// Adicionar los valores a los buckets

	for(size_t i = 0; i < size; i++){
		int index = get_bucket_index(array[i],max_value,n_threads);
		buckets[index] = add_bucket_value(buckets[index], array[i]);
	}

  // cada thread recibe un múmero de buckets

	for(int i = 0; i < n_threads; i++)
  	pthread_create(&threads[i], NULL, (void *) bubble_sort, (void *) &buckets[i]);

	// Espera a que los threads acaben
	for(int i = 0; i < n_threads; i++){
		pthread_join(threads[i], NULL);
	}

	// combina todos los valores
	combine_buckets(sort_array, buckets, n_threads);

	// imprime el tiempo
	printf("| | | utilizando %d thread(s)\n", n_threads);
	// libera buckets de memoria
	free_buckets(buckets, n_threads);

	// regresa vector ordenado
	return sort_array;
}//bucket_sort_pthreads

/** Asigna buckets en la memoria
	*	@param n_arrays - cantidad de arrays que serán devueltos
	* @return n vectores
	*/
Bucket *allocate_buckets(int n_arrays){
	Bucket *arrays;
	arrays = (Bucket *) malloc(n_arrays + 1000 * sizeof(Bucket));
	for(int i = 0; i < n_arrays; i++){
		arrays[i].array = NULL;
		arrays[i].size = 0;
	}

	return arrays;
}

/** Función que asigna valores a buckets
	* @param value - valor a indexar
	* @param max - valor maximo
	* @param n_buckets - cantidad de buckets
	* @return indice del vector
	*/
int get_bucket_index(int value, int max, int n_buckets){
	return (int) (value)/(max/n_buckets);
}

/** Función que adiciona un valor al bucket
	* @param array - bucket
	* @param value - valor adicionado al bucket
	* @return bucket con un valor indexado
	*/
Bucket add_bucket_value(Bucket array, int value){
	//printf("size : %d\n", (int) array.size);
	array.array = realloc(array.array, (array.size + 1) * sizeof(int));
	array.array[array.size] = value;
	array.size++;
	return array;
}

/** Algoritmo de ordenación Bubble Sort
	* @param array - Struct con un vector de su tamaño
	*/
void bubble_sort(void *array){
	Bucket *sort = (Bucket *) array;
	char flag;
	int temp;

	for(size_t i = 0; i < sort->size; ++i){
		flag = 1;

		for(size_t j = 0; j < sort->size - 1 - i; ++j){

			// Si el actual fo es mayor que el próximo, no entra.
			if(sort->array[j] > sort->array[j+1]){
				flag = 0;
				temp = sort->array[j];
				sort->array[j] = sort->array[j+1];
				sort->array[j+1] = temp;
			}
		}
		// Si no hubo problemas, está ordenado
		if(flag)
			return;
	}
	return;
}

/** Función que combina los buckets con el vector resultado
	* @param sort_array - vector que inicia ordenamiento
	* @param buckets - vector de buckets
	* @param n_buckets - cantidad de buckets
	*/
void combine_buckets(int *sort_array, Bucket *buckets, int n_buckets){
	int cont = 0;
	for(int i = 0; i < n_buckets; i++){
		for(size_t j = 0; j < buckets[i].size; j++)
			sort_array[cont++] = buckets[i].array[j];
	}
	for (int k = 0; k < n_buckets; k++) {
    printf("Tamaño Bucket[%d]: %zu\n",k+1, buckets->size);
		for(size_t l = 0; l < buckets[k].size; l++){
			printf("Bucket[%d]: %d\n", k+1, buckets[k].array[l]);
		}
	}
}

/** Libera los buckets de la memoria
	* @param buckets - buckets
	* @param n_buckets - cantidad de buckets
	*/
void free_buckets(Bucket *buckets, int n_buckets){
	for(int i = 0; i < n_buckets; i++)
		free(buckets[i].array);
	free(buckets);
}
